/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
module.exports = {
    ideas: [
        'Würfel: Calliope mini wird zum Zufallsgerät (sechs-flächiger Würfel) programmiert',
        '1x1-Rechentrainer: Calliope mini wird zum Kopfrechentrainer für das kleine 1x1 programmiert.',
        'Countdown: Calliope mini wird als Countdown-Zähler programmiert, bei dem die Startgröße selbst gewählt werden kann.',
        'Straßenbeleuchtung: Calliope mini steuert eine Strassenlaterne über das Tageslicht.',
        'Pflanzenbewässerung: Calliope mini misst die Feuchtigkeit der Blumenerde und gibt ein Signal, wenn gegossen werden muss.'
    ]
};
